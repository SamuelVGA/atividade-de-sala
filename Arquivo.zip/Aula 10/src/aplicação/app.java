package aplicação;


import entidades.Atendente;
import entidades.Cliente;
import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;

public class app {
    public static void main(String[] args) {

        Atendente novo_atendente = new Atendente();
        Cliente novo_cliente = new Cliente();
        System.out.println("Coloque o nome do Cliente ");
        Scanner entrada = new Scanner(System.in);
        novo_cliente.setNome = entrada.nextLine();
        System.out.println("Coloque o CPF do Cliente ");
        novo_cliente.setCpf = entrada.nextLine();
        System.out.println("Coloque a data de Nascimento do Cliente ");
        novo_cliente.setDataNascimento = entrada.nextLine();
        System.out.println("Coloque a profissão do Cliente ");
        novo_cliente.setProfissao = entrada.nextLine();
        System.out.println("Coloque o email do Cliente ");
        novo_cliente.setEmail = entrada.nextLine();







        Cliente novo_cliente = new Cliente();
        System.out.println("Coloque o nome do Cliente ");
        Scanner entrada = new Scanner(System.in);
        novo_cliente.setNome = entrada.nextLine();
        System.out.println("Coloque o CPF do Cliente ");
        novo_cliente.setCpf = entrada.nextLine();
        System.out.println("Coloque a data de Nascimento do Cliente ");
        novo_cliente.setDataNascimento = entrada.nextLine();
        System.out.println("Coloque a profissão do Cliente ");
        novo_cliente.setProfissao = entrada.nextLine();
        System.out.println("Coloque o email do Cliente ");
        novo_cliente.setEmail = entrada.nextLine();




    }

}

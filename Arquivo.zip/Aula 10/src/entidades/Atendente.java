package entidades;

import java.util.Date;

public class Atendente extends Cliente {
        private NivelSuporte nivelSuporte;


    public NivelSuporte getNivelSuporte() {
        return nivelSuporte;
    }

    public void setNivelSuporte(NivelSuporte nivelSuporte) {
        this.nivelSuporte = nivelSuporte;
    }

    public Atendente(NivelSuporte nivelSuporte) {
        this.nivelSuporte = nivelSuporte;
    }

    public Atendente(String nome, String cpf, Date dataNascimento, String profissao, String email, NivelSuporte nivelSuporte) {
        super(nome, cpf, dataNascimento, profissao, email);
        this.nivelSuporte = nivelSuporte;
    }


    public Atendente() {
        this.nivelSuporte = nivelSuporte;
    }
}

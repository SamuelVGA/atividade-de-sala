package entidades;

public enum NivelSuporte {
    SUPORTE,
    HELPDESK,
    ESPECIALIZADO,

}

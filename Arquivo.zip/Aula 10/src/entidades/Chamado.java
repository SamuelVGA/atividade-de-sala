package entidades;

import java.util.Date;

public class Chamado {
    private int id;
    private Date dataAbertura;
    private StatusSuporte status;
    private Cliente cliente;
    private Atendente atendente;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(Date dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public StatusSuporte getStatus() {
        return status;
    }

    public void setStatus(StatusSuporte status) {
        this.status = status;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Atendente getAtendente() {
        return atendente;
    }

    public void setAtendente(Atendente atendente) {
        this.atendente = atendente;
    }

    public Chamado() {

    }

    public Chamado(int id, Date dataAbertura, StatusSuporte status, Cliente cliente, Atendente atendente) {
        this.id = id;
        this.dataAbertura = dataAbertura;
        this.status = status;
        this.cliente = cliente;
        this.atendente = atendente;
    }
}

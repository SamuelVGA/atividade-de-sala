package entidades;

public enum StatusSuporte {
    ABERTO,
    TRATAMENTO,
    RESOLVIDO,

}

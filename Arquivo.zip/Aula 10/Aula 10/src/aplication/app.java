package aplication;

import entities.Circulo;
import entities.Forma;
import entities.Quadrado;

import java.awt.*;

public class app {

    public static void main(String[] args) {

        Forma f1 = new Quadrado(Color.BLACK,3.5,4.5);
        Forma f2 = new Circulo(Color.BLUE,5.0);

        System.out.println(f1.calcularArea());
        System.out.println(f2.calcularArea());


    }


}

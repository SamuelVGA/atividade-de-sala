package entities;

public enum color {
    BLACK,
    BLUE,
    RED,
    GREEN,
    RAINBOW;


}

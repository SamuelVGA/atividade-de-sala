package entities;

import java.awt.*;

public abstract class Forma {

    protected Color color;

    public Forma (){

    }

    public Forma(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public double calcularArea() {
        System.out.println("Calcular área ");
        return 2.0;

    }





}
